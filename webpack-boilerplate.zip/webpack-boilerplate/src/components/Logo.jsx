
import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserCircle } from '@fortawesome/free-solid-svg-icons';

const Logo =({mylogo}) => {
    return (
    
            <div className="logo">
               
             <FontAwesomeIcon icon={faUserCircle} color="black" size="2x" />
              
            </div>
        
    )
}



export default Logo;




